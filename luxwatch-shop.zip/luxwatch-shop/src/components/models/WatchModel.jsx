import React from 'react'
import { useFrame } from '@react-three/fiber'

export default function WatchModel({variant}) {
  // Demo procedural "watch" using primitives. Replace with <primitive object={gltf.scene} />
  // or use useGLTF('/models/your-watch.glb') from @react-three/drei
  const ringRef = React.useRef()
  useFrame((state, delta) => {
    if (ringRef.current) ringRef.current.rotation.y += delta * 0.3
  })

  // choose color by variant
  let color = '#cbd5e1'
  if (variant && variant.includes('patek')) color = '#fbbf24'
  if (variant && variant.includes('hublot')) color = '#0f172a'

  return (
    <group scale={0.9}>
      {/* strap */}
      <mesh position={[0,-0.9,0]} rotation={[0,0,0]}>
        <boxGeometry args={[3.2,0.3,0.3]} />
        <meshStandardMaterial metalness={0.2} roughness={0.6} color={'#0b1220'} />
      </mesh>

      {/* case */}
      <mesh position={[0,0,0]}>
        <cylinderGeometry args={[1.1,1.1,0.35,64]} />
        <meshStandardMaterial metalness={0.8} roughness={0.25} color={color} />
      </mesh>

      {/* dial */}
      <mesh position={[0,0.02,0.12]}>
        <circleGeometry args={[0.75,64]} />
        <meshStandardMaterial metalness={0.4} roughness={0.5} color={'#04263b'} />
      </mesh>

      {/* rotating bezel */}
      <mesh ref={ringRef} position={[0,0,0.02]}>
        <torusGeometry args={[1.05,0.08,16,100]} />
        <meshStandardMaterial metalness={0.9} roughness={0.2} color={'#3949ab'} />
      </mesh>

      {/* hands */}
      <mesh rotation={[0,0,0]} position={[0,0,0.15]}>
        <boxGeometry args={[0.02,0.7,0.02]} />
        <meshStandardMaterial color={'#f8fafc'} />
      </mesh>
    </group>
  )
}
