import React, {useState} from 'react'
import Product3DViewer from './Product3DViewer'

export default function ProductCard({product, onAdd}) {
  const [show3D, setShow3D] = useState(false)
  return (
    <div className="card">
      <div className="product-image">
        {show3D ? (
          <div style={{width:'100%', height:'100%'}}>
            <Product3DViewer variant={product.id} />
          </div>
        ) : (
          <div style={{textAlign:'center'}}>
            <div style={{fontSize:18, fontWeight:700}}>{product.brand}</div>
            <div style={{fontSize:14, color:'#94a3b8'}}>{product.model}</div>
            <div style={{marginTop:12, fontSize:13}}>${product.price.toLocaleString()}</div>
          </div>
        )}
      </div>
      <div style={{display:'flex', justifyContent:'space-between', alignItems:'center', marginTop:8}}>
        <div>
          <div style={{fontWeight:700}}>{product.model}</div>
          <div className="hint" style={{marginTop:6}}>{product.desc}</div>
        </div>
        <div style={{display:'flex', flexDirection:'column', gap:8}}>
          <button className="btn" onClick={onAdd}>Add</button>
          <button className="btn secondary" onClick={()=>setShow3D(s=>!s)}>{show3D ? 'Hide 3D' : 'View 3D'}</button>
        </div>
      </div>
    </div>
  )
}
