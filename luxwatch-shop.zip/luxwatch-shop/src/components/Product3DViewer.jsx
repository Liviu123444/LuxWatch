import React, { Suspense } from 'react'
import { Canvas } from '@react-three/fiber'
import { OrbitControls, Environment, Html } from '@react-three/drei'
import WatchModel from './models/WatchModel'

export default function Product3DViewer({variant}) {
  // variant prop can be used to switch models; demo uses primitive shapes
  return (
    <Canvas camera={{ position: [0, 0, 4] }} style={{height:'100%', borderRadius:8}}>
      <ambientLight intensity={0.6} />
      <directionalLight position={[5,5,5]} intensity={1} />
      <Suspense fallback={<Html center>Loading 3D...</Html>}>
        <WatchModel variant={variant} />
        <Environment preset="city" />
      </Suspense>
      <OrbitControls />
    </Canvas>
  )
}
