import React from 'react'

export default function Header({cartCount}) {
  return (
    <header className="header">
      <div style={{display:'flex', alignItems:'center', gap:16}}>
        <div className="logo card" style={{display:'flex', alignItems:'center', gap:12, padding:'8px 12px'}}>
          <div className="mark">LW</div>
          <div>
            <div style={{fontWeight:800}}>LuxWatch</div>
            <div style={{fontSize:12, color:'#94a3b8'}}>Luxury watches — demo shop</div>
          </div>
        </div>
        <nav style={{display:'flex', gap:12, color:'#cfe8ff'}}>
          <a href="#" style={{textDecoration:'none'}}>Home</a>
          <a href="#" style={{textDecoration:'none'}}>Brands</a>
          <a href="#" style={{textDecoration:'none'}}>Contact</a>
        </nav>
      </div>
      <div style={{display:'flex', gap:12, alignItems:'center'}}>
        <div className="hint">Secure Checkout (demo)</div>
        <button className="btn secondary">Sign in</button>
        <button className="btn">Cart ({cartCount})</button>
      </div>
    </header>
  )
}
