import React from 'react'

export default function Cart({items, onUpdate, onRemove}) {
  const total = items.reduce((s,i)=>s + i.price * i.qty, 0)
  return (
    <aside className="sidebar card">
      <h3>Cart</h3>
      {items.length === 0 ? (
        <div className="hint" style={{marginTop:12}}>Your cart is empty.</div>
      ) : (
        <>
          <ul style={{listStyle:'none', padding:0, margin:0, display:'grid', gap:12}}>
            {items.map(it=>(
              <li key={it.id} style={{display:'flex', gap:12, alignItems:'center', justifyContent:'space-between'}}>
                <div>
                  <div style={{fontWeight:700}}>{it.model}</div>
                  <div className="hint">${it.price.toLocaleString()}</div>
                </div>
                <div style={{display:'flex', gap:8, alignItems:'center'}}>
                  <input aria-label="qty" type="number" min="1" value={it.qty} onChange={(e)=>onUpdate(it.id, Math.max(1, parseInt(e.target.value||1)))} style={{width:60, padding:6, borderRadius:8, border:'none'}}/>
                  <button className="btn secondary" onClick={()=>onRemove(it.id)}>Remove</button>
                </div>
              </li>
            ))}
          </ul>
          <div style={{marginTop:14, display:'flex', justifyContent:'space-between', alignItems:'center'}}>
            <div>
              <div className="hint">Subtotal</div>
              <div style={{fontWeight:800, fontSize:18}}>${total.toLocaleString()}</div>
            </div>
            <div style={{display:'flex', flexDirection:'column', gap:8}}>
              <button className="btn">Checkout (Demo)</button>
              <button className="btn secondary">Continue shopping</button>
            </div>
          </div>
        </>
      )}
      <div style={{marginTop:12}} className="hint">* This is a demo store. Integrate Stripe or PayPal for real payments.</div>
    </aside>
  )
}
