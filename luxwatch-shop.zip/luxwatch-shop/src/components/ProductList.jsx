import React from 'react'
import ProductCard from './ProductCard'

export default function ProductList({products, onAdd}) {
  return (
    <section style={{flex:1}}>
      <h2 style={{margin:'8px 0 18px 0'}}>Featured Watches</h2>
      <div className="products">
        {products.map(p => <ProductCard key={p.id} product={p} onAdd={()=>onAdd(p)} />)}
      </div>
    </section>
  )
}
