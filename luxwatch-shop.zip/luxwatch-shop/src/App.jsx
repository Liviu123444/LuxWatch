import React, { useState } from 'react'
import ProductList from './components/ProductList'
import Cart from './components/Cart'
import Header from './components/Header'
import productsData from './data/products'

export default function App() {
  const [cart, setCart] = useState([])

  function addToCart(product) {
    setCart(prev => {
      const existing = prev.find(p => p.id === product.id)
      if (existing) {
        return prev.map(p => p.id === product.id ? {...p, qty: p.qty + 1} : p)
      }
      return [...prev, {...product, qty: 1}]
    })
  }

  function updateQty(id, qty) {
    setCart(prev => prev.map(p => p.id === id ? {...p, qty} : p).filter(p => p.qty > 0))
  }

  function removeItem(id) {
    setCart(prev => prev.filter(p => p.id !== id))
  }

  return (
    <div className="app">
      <Header cartCount={cart.reduce((s,i)=>s+i.qty,0)} />
      <main className="container">
        <ProductList products={productsData} onAdd={addToCart} />
        <Cart items={cart} onUpdate={updateQty} onRemove={removeItem} />
      </main>
      <footer className="footer">
        <small>LuxWatch — demo shop · Replace demo assets & add payment backend before production.</small>
      </footer>
    </div>
  )
}
