const products = [
  {
    id: 'rolex-submariner',
    brand: 'Rolex',
    model: 'Submariner (Demo)',
    price: 12900,
    desc: 'Classic diver's watch inspired demo. Replace with exact model details and images for production.',
    color: 'steel',
    gallery: []
  },
  {
    id: 'hublot-classic',
    brand: 'Hublot',
    model: 'Classic Fusion (Demo)',
    price: 11500,
    desc: 'Modern Hublot-style demo watch.',
    color: 'black',
    gallery: []
  },
  {
    id: 'patek-nautilus',
    brand: 'Patek Philippe',
    model: 'Nautilus (Demo)',
    price: 42000,
    desc: 'Elegant luxury watch demo for presentation.',
    color: 'gold',
    gallery: []
  }
]

export default products
